﻿$src = "C:\Users\28587\Documents\Powershell Scripts"
$sendmail = $false

 Get-ChildItem -path $src -Recurse |
 Foreach-Object { 
 	  #write-host $_.fullname
	  $dtdiff = New-TimeSpan ($_.LastWriteTime) $(Get-Date)
	  
	  if ($dtdiff.minutes -gt 10){
	  	$strbody = $strbody +$_.fullname+ " - Last Modified Time: "  +$_.LastWriteTime +  "`r`n" 
		$sendmail = $true
		}		
}

write 
$strbody 

if($sendmail -eq $true){
# Email components
$strFromAddress = "SVishwanatha.Naik@itcinfotech.com"
$strToAddress = "SVishwanatha.Naik@itcinfotech.com"
$strMessageSubject = "REPORT"
$strMessageBody = $strbody
$strSendingServer = "10.6.12.154"

$strSendingServer

# Email objects
$objSMTPMessage = New-Object System.Net.Mail.MailMessage $strFromAddress, $strToAddress, $strMessageSubject, $strMessageBody

Write-Host "SMPT Message"
$objSMTPMessage

$objSMTPClient = New-Object System.Net.Mail.SMTPClient $strSendingServer

Write-Host "Server name and action"
$objSMTPClient


$objSMTPClient.Send($objSMTPMessage)

}