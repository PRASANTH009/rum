﻿
####################################################################################################
#                             View Book Working!!!!                                                #
####################################################################################################

[xml]$xdoc = Get-Content D:\Xml_Files\Books.xml
        
            $search = "author"     
            #replace "author" here for view tilte , price, genere, publish_date wrt
            $search_Par = "bing"
   $node = $xdoc.catalog.book | % {$_.$search}|?{$_ -match $search_Par} |select -First 1
   $new = $xdoc.catalog.book | Where-Object {$_.author -eq $node} 
   $new | Out-GridView