﻿Add-Type -AssemblyName System.Windows.Forms
$FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{
    Multiselect = $true # Multiple files can be chosen
	Filter = 'XML (*.xml)|*.xml;' # Specified file types
}
 
[void]$FileBrowser.ShowDialog()

$path = $FileBrowser.FileNames;

[xml]$XmlDocument = Get-Content -Path $path
$XmlDocument.GetType().FullName
$XmlDocument
$XmlDocument.Cars
$XmlDocument.Cars.Car | Format-Table -AutoSize
$XmlDocument.Cars.Car[0]|Format-Table -AutoSize