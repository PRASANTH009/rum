﻿ $choice = Read-Host "Choose: 
1.to enter path 
2. choose from file browser
===>>>"

if ($choice -eq 1){
$src = Read-Host "Enter the path"
}
elseif($choice -eq 2){
#Dialog box pop up for choosing a file
Add-Type -AssemblyName System.Windows.Forms
$FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{
    Multiselect = $true           # Multiple files can be chosen on same pop up window
    Filter = 'All Files (*.*)|*.*;'       #select any file type.
}
 
[void]$FileBrowser.ShowDialog()

$src = $FileBrowser.FileNames;
#$path conatins the path of files selected 
}
else{
Write-Host "invalid choice"
return
}

$DestZip = "D:\test\"
$folder = Get-Item -Path $Src
$ZipTimestamp = Get-Date -format ddMMMyyyy-HHmmss
$ZipFileName  = $DestZip + "Backup_" + $folder1.name + "_" + $ZipTimestamp + ".zip"
$ZipFileName
$folder
$src
$ZipTimestamp
Write-Host "back up folders " $Src 
set-content $ZipFileName ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18))
 # Wait for the zip file to be created.
    while (!(Test-Path -PathType leaf -Path $ZipFileName))
    {    
        Start-Sleep -Milliseconds 20
    } 
    $ZipFile = (new-object -com shell.application).NameSpace($ZipFileName)

    Write-Output (">> Waiting Compression : 
    " + $ZipFileName)  
    #BACKUP - COPY
    $ZipFile.CopyHere($Src)
    write-Host "saved in" $ZipFileName