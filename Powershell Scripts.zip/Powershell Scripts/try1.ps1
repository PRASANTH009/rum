﻿Add-Type -AssemblyName System.Windows.Forms
 
$FolderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog -Property @{
    Multiselect = $true # Multiple files can be chosen
    ShowNewFolderButton = $false
}
 
[void]$FolderBrowser.ShowDialog()
$src = $FolderBrowser.SelectedPath
 
Add-Type -AssemblyName System.Windows.Forms
 
$FolderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog -Property @{
    ShowNewFolderButton = $true
}
 
[void]$FolderBrowser.ShowDialog()
$des = $FolderBrowser.SelectedPath
 

Add-Type -AssemblyName "system.io.compression.filesystem"

[io.compression.zipfile]::CreateFromDirectory($src, $des)

try {
    Remove-Item -Path $src -ErrorAction Stop
} catch [System.Management.Automation.ItemNotFoundException] {
    "sOURCE fILE tO cONVERT nOT fOUND"
} 