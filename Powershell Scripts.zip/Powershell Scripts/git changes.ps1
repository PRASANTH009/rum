﻿$sendmail = $false

$gitlog=git whatchanged --since "yesterday" --until "today"
$gitlog 


if($sendmail -eq $true){
# Email components
$strFromAddress = "SVishwanatha.Naik@itcinfotech.com"
$strToAddress = "SVishwanatha.Naik@itcinfotech.com"
$strMessageSubject = "REPORT"
$strMessageBody = $strbody
$strSendingServer = "10.6.12.154"

$strSendingServer

# Email objects
$objSMTPMessage = New-Object System.Net.Mail.MailMessage $strFromAddress, $strToAddress, $strMessageSubject, $strMessageBody

Write-Host "SMPT Message"
$objSMTPMessage

$objSMTPClient = New-Object System.Net.Mail.SMTPClient $strSendingServer

Write-Host "Server name and action"
$objSMTPClient


$objSMTPClient.Send($objSMTPMessage)

}