﻿#to see in size GB and MB. Later to make function and use it.
$foldersize = Get-ChildItem D:\letusc -recurse | Measure-Object -property length -sum
# Convert it from Bytes into GB
$folderSizeInGB = $foldersize.sum / 1GB
# Convert it from Bytes into GB
$folderSizeInMB = $foldersize.sum / 1MB
Write-Host "D:\letusc is of "  $folderSizeInGB "GB and " $folderSizeInMB "MB"



Get-ChildItem -Path D:   #lists all files and folders
Get-ChildItem -Path D: -Recurse  #lists files in folders and files in folders and sub folder
 

#  –Directory, -File,  -Hidden, and –System different operations can be performed
Get-ChildItem -Path D:\letusc -Recurse -file #lists all the files in a folder
Get-ChildItem -Path D:\letusc -Recurse -Hidden #lists hidden files
Get-ChildItem -Path D:\letusc -Recurse -Directory #lists folder name or directories


#lists all the files according to thier length in decending order
Get-ChildItem -Path D:\letusc | sort Length -Descending
 

####################################################################################################
# To Find the largest file in a particular Directory: 
# -include                                 : mention extension type
# -recurse                                 : lists files and subfolder in a dir
# -ErrorAction "silentlyContinue"          : Exception 
# ? { $_.GetType().Name -eq "FileInfo" }   : if file name is equal to file information
# $_.Length -gt 0MB                        : size of file should be greater than 0 MB
# "{0:N0}" -f ($_.Length / 1MB)            : Conversion of bytes to MB
# -first 1                                 : only first wil be printed
# -first 10                                : will print the top 10 
# sort-Object -property length -Descending : sorts and prints according size
####################################################################################################

$largeSizefiles = get-ChildItem -path D: -include "*.*" -recurse -ErrorAction "SilentlyContinue" | 
? { $_.GetType().Name -eq "FileInfo" } |
where-Object {$_.Length -gt 0MB } | sort-Object -property length -Descending  |
Select-Object Name,
  @{Name="Size In MB";Expression={ "{0:N0}" -f ($_.Length / 1MB)}},
  @{Name="LastWriteTime";Expression={$_.LastWriteTime}},@{Name="Path";Expression={$_.directory}} -first 1

  Write-Host  -ForegroundColor  DarkGreen "largest file in D:"
  $largeSizefiles 

 

