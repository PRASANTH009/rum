﻿param(
[Parameter(Mandatory=$true,Position=0)]
[string]$path,
[Parameter(Mandatory=$true,Position=0)]
[string]$username
)
cd $path  

$commitinfo = ( git log --author=$username )  
if($commitinfo -eq $null)
{
Write-Host "no commits by" $username
}

else {
$commitinfo
} 