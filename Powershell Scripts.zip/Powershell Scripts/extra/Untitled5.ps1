﻿[xml]$xdoc = Get-Content D:\Xml_Files\Books.xml
$del_book = $xdoc.catalog.book | Where-Object {$_.author -eq $author_name} | sort book |group book -NoElement
$xdoc.catalog.book | % {$_.title}|?{$_ -match "cook"} | Format-Table id,author,title,price

$node = $xdoc.catalog.book | % {$_.author}|?{$_ -match "bing"} |select -First 1
    if($xdoc.catalog.book -contains $node)
    {
    Write-Host $xdoc.catalog.book
    }


 $xdoc.catalog.ChildNodes | % {$_.author}|?{$_ -match "bing"}

 $xdoc.catalog.ChildNodes | % {$_.author}

 $xdoc.catalog.book | % {$_.author}
 
$xdoc.catalog |Get-Member  -MemberType Property | select author | sort bing |group bing -NoElement
$xdoc.catalog | Get-ChildItem(2)
$xdoc.catalog.book | % {$_.author} 

$xdoc.catalog |Get-Member  -MemberType Property
$xdoc.catalog.GetAttribute()
 $node | Select-Object -ExcludeProperty ChildNodes
 $xdoc.catalog.book | Format-Table id,author,title,price -AutoSize
$xdoc.catalog.ChildNodes | Format-Table id,author,title,price -AutoSize |% {$_.author}|?{$_ -match "bing"}

  $xdoc.catalog.book | where {$_.author.startswith("b")}

  Select-Xml -Content $xdoc -XPath '/catalog/book [../author == bing]' | % {$_.Node}

  $xdoc.SelectNodes('//@book') | Select-Object -ExpandProperty 'bing'

 $xdoc | Select-Xml -XPath "//catalog/book[@author='bing']"
 select -f




 [xml]$xdoc = Get-Content D:\Xml_Files\Books.xml
$del_book = $xdoc.catalog.book | Where-Object {$_.author -eq "Bing"}
 $del_book
$viewBook = $xdoc.catalog.
Write-Host "the above book deleted succesfully." $viewBook

