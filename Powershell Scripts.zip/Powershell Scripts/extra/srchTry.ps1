﻿[xml]$xdoc = Get-Content D:\Xml_Files\Books.xml

$node = $xdoc.catalog.book | % {$_.author}|?{$_ -match "bing"} |select -First 1
$node
    if($xdoc.catalog.book.Contains( $node))
    {
    Write-Host "yes"
    }
    

    $xdoc.catalog.SelectSingleNode(“//book[preceding-sibling::book[contains(author, ‘Kress’)]]/price”)

    $xdoc.SelectSingleNode(

    “//book[contains(author, ‘Kress’)]/

        following-sibling::book/price”)

        $xdoc.catalog.book |
    % { $_.author } |

    select -Unique

