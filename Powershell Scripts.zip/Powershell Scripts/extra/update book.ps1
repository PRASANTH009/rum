﻿$path = 'D:\Books.xml'
[xml]$xdoc = Get-Content $path

$index_value = Read-Host "enter index value "

if($index_value -ge $xdoc.catalog.book.Count){

$author_name = Read-Host "enter author name "
$title       = Read-Host "enter title "
$price       = Read-Host "enter price "

if ($xdoc.catalog.book.author[$index_value] -ne $author_name) {
$xdoc.catalog.book[$index_value].author = $author_name
}
else {
Write-Host "Author name already exists, Hence value won't be changed"
}

if ($xdoc.catalog.book.title[$index_value] -ne $title) {
$xdoc.catalog.book[$index_value].title = $title
}
else {
Write-Host "title value already exists, Hence value won't be changed already exists"
}

if ($xdoc.catalog.book.price[$index_value] -ne $price) {
$xdoc.catalog.book[$index_value].price = $price
}
else {
Write-Host "price value already exists, Hence value won't be changed already exists"
}
}
else {
Write-Warning "Wrong Index Value or Index value is not present."
}
$xdoc.Save("D:\Books.xml")