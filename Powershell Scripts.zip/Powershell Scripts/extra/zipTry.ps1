﻿#Dialog box pop up for choosing a file
    Add-Type -AssemblyName System.Windows.Forms
    $FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{
    Multiselect = $true           # Multiple files can be chosen on same pop up window
    Filter = 'All Files (*.*)|*.*;'       #select any file type.
    }
 
    [void]$FileBrowser.ShowDialog()

 
#$source conatins the path of files selected
    
    
    $Source = $FileBrowser.FileNames;
    $DestZip = "C:\Users\28587\Downloads\"

    $folder = Get-Item -Path $Source

    $ZipTimestamp = Get-Date -format ddMMMyyyy-HHmmss;
    $ZipFileName  = $DestZip + "Backup_" + $folder.name + "_" + $ZipTimestamp + ".zip" 

    $Source

    set-content $ZipFileName ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18)) 
    # Wait for the zip file to be created.
    while (!(Test-Path -PathType leaf -Path $ZipFileName))
    {    
        Start-Sleep -Milliseconds 20
    } 
    $ZipFile = (new-object -com shell.application).NameSpace($ZipFileName)

    Write-Output (">> Waiting Compression : " + $ZipFileName)       

    #BACKUP - COPY
    $ZipFile.CopyHere($Source) 

    $ZipFileName
    # ARCHIVE

    write-Host "saved in downloads C:\Users\28587\Downloads."