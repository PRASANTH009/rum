﻿#$myPath = 'D:\Xml_Files\replace.txt'
#Get-Content $myPath | ForEach-Object { $_ -replace  "bbb" , "aaa"} 
#Set-Content $myPath

$InputFiles = Get-Item "D:\Xml_Files\*.txt"
if ($InputFiles -ne $null){
$OldString  = Read-Host -Prompt 'Search for String you want to replace'
if (Select-String -Path $InputFiles -Pattern $OldString -SimpleMatch -Quiet)
{
Write-Host $OldString -BackgroundColor DarkGreen "present in" $InputFiles
Write-Host -BackgroundColor DarkGray 'Input String you want to replace  {"' $OldString '"} with :'  
$NewString  = Read-Host 
$InputFiles | ForEach { (Get-Content -Path $_.FullName).Replace($OldString,$NewString) | Set-Content -Path $_.FullName }
}
else
{
Write-Host $OldString -BackgroundColor Magenta "is Not Present in " 
write-host $InputFiles
}
}
else{Write-Host "file not found"}