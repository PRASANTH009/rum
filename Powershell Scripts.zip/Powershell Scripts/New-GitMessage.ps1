﻿
#New-GitMessage.ps1
 
<#
e
#>
 
Function New-GitMessage {
[cmdletbinding()]
 
Param([string]$Text = $psise.CurrentFile.Editor.SelectedText)
 
#insert the selected text into a global variable.
$global:msg = $text
 
}
#create a shortcut in the ISE
$psise.CurrentPowerShellTab.AddOnsMenu.Submenus.Add("Commit Msg",{New-GitMessage},$null) | Out-Null
$psise.CurrentPowerShellTab.ConsolePane