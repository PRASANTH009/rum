﻿####################################################################################################
#                             function to select a folder                                          #
####################################################################################################
Function Get-Folder($initialDirectory)

{
    [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms")|Out-Null

    $foldername = New-Object System.Windows.Forms.FolderBrowserDialog
    $foldername.Description = "Select a folder"
    $foldername.rootfolder = "MyComputer"
    $foldername.ShowNewFolderButton = $false
    
    if($foldername.ShowDialog() -eq "OK")
    {
        $folder += $foldername.SelectedPath
    }
    else
    {
        Write-Host -ForegroundColor DarkRed -BackgroundColor DarkYellow "Cancelled By User"
    }
    return $folder
}


####################################################################################################
#                             function to select a  file                                           #
####################################################################################################
function Get-File()
{
    Read-Host "Enter any key to select file"
    #Dialog box pop up for choosing a file

    Add-Type -AssemblyName System.Windows.Forms
    $FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{
    Multiselect = $true           # Multiple files can be chosen on same pop up window
    Filter = 'All Files (*.*)|*.*;'       #select any file type.
    }
 
    if($FileBrowser.ShowDialog() -eq "OK")
    {
        $path = $FileBrowser.FileNames;
    }
    else
    {
        Write-Host -ForegroundColor DarkRed -BackgroundColor DarkYellow "Cancelled By User"
    }
    return $path     #$path conatins the path of files selected
 }

 Export-ModuleMember -function Get-Folder,Get-File -Alias gfldr, gfl

 #the above line will export the module function members.