﻿function Add-Value
{

param(
[Parameter(Mandatory=$true,Position=0)]
[string]$index_value,

[Parameter(Mandatory=$true,Position=1)]
[string]$author_name,

[Parameter(Mandatory=$true,Position=2)]
[string]$title,

[Parameter(Mandatory=$true,Position=3)]
[string]$price
)
[xml]$xdoc = Get-Content D:\Books.xml

if ($xdoc.catalog.book.author[$index_value] -ne $author_name) {
$xdoc.catalog.book[$index_value].author = $author_name
}
else {
Write-Host "Author name already exists, Hence value won't be changed"
}

if ($xdoc.catalog.book.title[$index_value] -ne $title) {
$xdoc.catalog.book[$index_value].title = $title
}
else {
Write-Host "title value already exists, Hence value won't be changed already exists"
}


if ($xdoc.catalog.book.price[$index_value] -ne $price) {
$xdoc.catalog.book[$index_value].price = $price
}
else {
Write-Host "price value already exists, Hence value won't be changed already exists"
}

$xdoc.Save("D:\Books.xml")
}



function Delete-Book
{
param(
[Parameter(Mandatory=$true,Position=0)]
[string]$index_value,

[Parameter(Mandatory=$true,Position=1)]
[string]$author_name
<#
[Parameter(Mandatory=$true,Position=2)]
[string]$title,

[Parameter(Mandatory=$true,Position=3)]
[string]$price
#>

)
[xml]$xdoc = Get-Content D:\Books.xml

if ($xdoc.catalog.book.author[$index_value] -eq $author_name) {
$xdoc.RemoveChild($author_name)
}
else {
Write-Host "Author name Doesnot exists."
}
<#
if ($xdoc.catalog.book.title[$index_value] -ne $title) {
$xdoc.catalog.book[$index_value].title = $title
}
else {
Write-Host "title value already exists, Hence value won't be changed already exists"
}

if ($xdoc.catalog.book.price[$index_value] -ne $price) {
$xdoc.catalog.book[$index_value].price = $price
}
else {
Write-Host "price value already exists, Hence value won't be changed already exists"
}
#>

$xdoc.Save("D:\Books.xml")

}