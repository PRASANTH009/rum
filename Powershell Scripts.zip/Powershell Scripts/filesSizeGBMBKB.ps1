﻿
Function Get-FormattedNumber($size) 
{ 
  IF($size -ge 1GB) 
   { 
      "{0:n2}" -f  ($size / 1GB) + " GigaBytes" 
   } 
 ELSEIF($size -ge 1MB) 
    { 
      "{0:n2}" -f  ($size / 1MB) + " MegaBytes" 
    } 
 ELSE 
    { 
      "{0:n2}" -f  ($size / 1KB) + " KiloBytes" 
    } 
  }
 

 
    
$largeSizefiles = get-ChildItem -path D: -include "*.*" -recurse -ErrorAction "SilentlyContinue" | 
? { $_.GetType().Name -eq "FileInfo" } |
 where-Object {$_.Length -gt 0MB } | sort-Object -property length -Descending  |
 Select-Object Name,
  @{Name="Size In MB";Expression={ "{0:N0}" -f ($_.Length / 1MB)}},
  @{Name="LastWriteTime";Expression={$_.LastWriteTime}},@{Name="Path";Expression={$_.directory}} -first 1


  $largeSizefiles



















