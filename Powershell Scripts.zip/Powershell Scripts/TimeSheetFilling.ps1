﻿#############################################################################
# Capturing a screenshot
#############################################################################
$File = "C:\Users\28587\Documents\Powershell Scripts\ScreenShots\MyFancyScreenshot.bmp"
Add-Type -AssemblyName System.Windows.Forms
Add-type -AssemblyName System.Drawing
# Gather Screen resolution information
$Screen = [System.Windows.Forms.SystemInformation]::VirtualScreen
$Width = $Screen.Width
$Height = $Screen.Height
$Left = $Screen.Left
$Top = $Screen.Top
# Create bitmap using the top-left and bottom-right bounds
$bitmap = New-Object System.Drawing.Bitmap $Width, $Height
# Create Graphics object
$graphic = [System.Drawing.Graphics]::FromImage($bitmap)
# Capture screen
$graphic.CopyFromScreen($Left, $Top, 0, 0, $bitmap.Size)
# Save to file
$bitmap.Save($File) 
Write-Output "Screenshot saved to:"
Write-Output $File
#############################################################################


$R=Invoke-WebRequest https://i3lmobile.itcinfotech.com/psp/OPPORTAL/?cmd=login -SessionVariable test
Get-Screenshot "C:\Users\28587\Documents\Powershell Scripts\ScreenShots" -jpeg
$test
$Form = $R.Forms[0]
Write-Host "Prints Form"
$Form | Format-List
Write-Host "Prints Form fileds"
$Form.fields
$Form.Fields["userid"]="28587"
$Form.Fields["pwd"]="Vish@123"
$R=Invoke-WebRequest -Uri ("https://i3lmobile.itcinfotech.com/psp/OPPORTAL/?cmd=login" + $Form.Action) -WebSession $test -Method POST -Body $Form.Fields