﻿$src="C:\Users\28587\Documents\Powershell Scripts"
$sendmail = $false

 Get-ChildItem -path $src -Recurse |
 Foreach-Object { 
 	  #write-host $_.fullname
	  $dtdiff = New-TimeSpan ($_.LastWriteTime) $(Get-Date)
	  
	  if ($dtdiff.minutes -gt 10){
	  	$strbody = $strbody +$_.fullname+ " - Last Modified Time: "  +$_.LastWriteTime +  "`r`n" 
		$sendmail = $true
		}		
}

$head = @"
<Title>$strbody</Title>
<style>
body { background-color:#FFFFFF;
font-family:Tahoma;
font-size:12pt; }
td, th { border:1px solid black;
border-collapse:collapse; }
th { color:white;
background-color:black; }
table, tr, td, th { padding: 2px; margin: 0px }
table { width:95%;margin-left:5px; margin-bottom:20px;}
</style>
<br>
<H1>$strbody</H1>
"@

[string]$strbody = ConvertTo-HTML -Head $head -Body $html.InnerXml -PostContent "<h6>Created $(Get-Date)</h6>"


Send-MailMessage -From SVishwanatha.Naik@itcinfotech.com -Subject "new updated report" -To SVishwanatha.Naik@itcinfotech.com -Body $strbody -BodyAsHtml -DeliveryNotificationOption OnSuccess -Port 25 -Priority Normal -SmtpServer 10.6.12.154
