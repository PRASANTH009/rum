﻿
    $Source1 = "C:\Users\28587\Documents\Powershell Scripts" 
    $Source2 = "C:\Users\28587\Documents\python"
    $DestZip = "C:\Users\28587\Downloads\"

    $folder1 = Get-Item -Path $Source1
    $folder2 = Get-Item -Path $Source2

    $ZipTimestamp = Get-Date -format ddMMMyyyy-HHmmss;
    $ZipFileName  = $DestZip + "Backup_" + $folder1.name + "_" + $ZipTimestamp + ".zip" 
    $ZipFileName2  = $DestZip + "Backup_" + $folder2.name + "_" + $ZipTimestamp + ".zip"

    Write-Host "back up folders "   $Source1  "and "  $Source2

    set-content $ZipFileName ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18)) 
    set-content $ZipFileName2 ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18)) 

    # Wait for the zip file to be created.
    while (!(Test-Path -PathType leaf -Path $ZipFileName))
    {    
        Start-Sleep -Milliseconds 20
    } 
    $ZipFile = (new-object -com shell.application).NameSpace($ZipFileName)

    Write-Output (">> Waiting Compression : 
    " + $ZipFileName)    
    
    # Wait for the zip file to be created.
    while (!(Test-Path -PathType leaf -Path $ZipFileName2))
    {    
        Start-Sleep -Milliseconds 20
    } 
    $ZipFile2 = (new-object -com shell.application).NameSpace($ZipFileName2)

    Write-Output - (">> Waiting Compression : 
    "+ $ZipFileName2)    

    #BACKUP - COPY
    $ZipFile.CopyHere($Source1) 
    $ZipFile2.CopyHere($Source2) 

    $ZipFileName
    $ZipFileName2

    # ARCHIVE

    write-Host "saved in downloads C:\Users\28587\Downloads."