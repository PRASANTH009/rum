﻿#Dialog box pop up for choosing a file
Add-Type -AssemblyName System.Windows.Forms
$FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{
    Multiselect = $true           # Multiple files can be chosen on same pop up window
    Filter = 'All Files (*.*)|*.*;'       #select any file type.
}
 
[void]$FileBrowser.ShowDialog()

$src = $FileBrowser.FileNames;
#$path conatins the path of files selected 

$folder = Get-Item -Path $Src
$ZipTimestamp = Get-Date -format ddMMMyyyy-HHmmss
$folder
$src
$ZipTimestamp
 
$des = "D:\test\" #Backup_" + $folder.name + "_" + $ZipTimestamp + ".zip"
$des

Add-Type -AssemblyName "system.io.compression.filesystem"

[io.compression.zipfile]::CreateFromDirectory($src, $des)

try {
    Remove-Item -Path $src -ErrorAction Stop
} catch [System.Management.Automation.ItemNotFoundException] {
    "sOURCE fILE tO cONVERT nOT fOUND"
} 