﻿#function to list type of file specified.
function List-Files ( [string]$arg1){
$list=Get-ChildItem -path $a | Where-Object { $_.Name -match $arg1}
if ($list -eq $null) 
{
Write-Host "No" $arg1 "files present"
}
else 
{
$list
} 
}

#function to select a folder 
Function Get-Folder($initialDirectory)

{
    [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms")|Out-Null

    $foldername = New-Object System.Windows.Forms.FolderBrowserDialog
    $foldername.Description = "Select a folder"
    $foldername.rootfolder = "MyComputer"
    $foldername.ShowNewFolderButton = $false
    
    if($foldername.ShowDialog() -eq "OK")
    {
        $folder += $foldername.SelectedPath
    }
    return $folder
}

$a = Get-Folder      #folder name is stored in $a var

#choice to select type of file 
$svalue = Read-Host "select an option:
        1. List text files.
        2. List PDF files.
        3. List log fiels.
      "
switch($svalue)
    {
      1
        {
        List-Files(".txt")
        }
      2
        {   
        List-Files(".pdf")
        }
      3
        {
        List-Files(".log")
        }
    }  
