﻿$Source = "C:\Users\28587\Documents\BAT\Brand Activation.pbix"
$ZipDestination = "D:\pbix files\Zip file\PBIXtest.zip"
$ExtractZipTo = "D:\pbix files\Extracted file\"
 If(Test-path $ZipDestination) {Remove-item $ZipDestination}

Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction Stop

[io.compression.zipfile]::CreateFromDirectory($Source, $ZipDestination)
[System.IO.Compression.ZipFile]::ExtractToDirectory( $ZipDestination, $ExtractZipTo )

$Overwrite = $true
$ShowDestinationFolder = $true

 
if ($ShowDestinationFolder) 
{
 explorer.exe $ExtractZipTo
}