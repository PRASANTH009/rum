﻿Write-Host "Comment and Uncomment"


 $content = Get-Item "D:\Xml_Files\ConstServ1.js"

 $InputFiles = Get-Content -Path $content  

$SIT_Start ="/\*//SIT_Dev"
$SIT_Startre = "//SIT DEV"
$SIT_End = "SIT_DEV_ENDS\*/"
$SIT_Endre = " "

$InputFiles | ForEach { (Get-Content -Path $_.FullName).Replace($SIT_Start,$SIT_Startre) | Set-Content -Path $_.FullName }
$InputFiles | ForEach { (Get-Content -Path $_.FullName).Replace($SIT_End,$SIT_Endre) | Set-Content -Path $_.FullName }