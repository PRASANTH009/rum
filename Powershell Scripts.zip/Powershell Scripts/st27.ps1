﻿$Path = D:\Xml_Files\Books.xml

$ObjectProperties = "Author","Keywords"

$Application = New-Object -ComObject Word.Application
$Application.Visible = $false
$Binding = "System.Reflection.BindingFlags" -as [type]

$Select = "title","price"
$Select += $ObjectProperties

ForEach ($File in (Get-ChildItem $Path -Include *.doc -Recurse))
{   $Document = $Application.Documents.Open($File.Fullname)
    $Properties = $Document.BuiltInDocumentProperties
    $Hash = @{}
    $Hash.Add("title",$File.title)
    $Hash.Add("price",$File.price)
    ForEach ($Property in $ObjectProperties)
    {   $DocProperties = [System.__ComObject].InvokeMember("item",$Binding::GetProperty,$null,$Properties,$Property)
        Try {
            $Value = [System.__ComObject].InvokeMember("value",$binding::GetProperty,$null,$DocProperties,$null)
        }
        Catch {
            $Value = $null
        }
        $Hash.Add($Property,$Value)
    }
    $Document.Close()
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($Properties) | Out-Null
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($Document) | Out-Null
    New-Object PSObject -Property $Hash | Select $Select
}
$Application.Quit()

