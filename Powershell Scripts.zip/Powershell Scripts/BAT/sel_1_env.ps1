Write-Host "Hello World"

# Use the environment variables input below to pass secret variables to this script.

Write-Host "Welcome !!! its to replace the string in a file."
$FilePath  = Get-Item "$Env:BUILD_REPOSITORY_LOCALPATH"
Write-Host "the repo"
$Env:BUILD_REPOSITORY_LOCALPATH
$InputFiles = Get-ChildItem -Path $FilePath ConstService.js -Recurse -Force
if ($InputFiles -ne $null){
$envVersionOld= "$envVersion"
$envAppNameOld = "$envAppName"
$envMianUrlOld = "$envmainUrl"

if (Select-String -Path $InputFiles -Pattern $envVersionOld -SimpleMatch -Quiet)
{
Write-Host $OldString -BackgroundColor DarkGreen "present in" $InputFiles 

if ($env:SITDevEnvVersion -eq $null)
	{
	if ($env:SITTestEnvVersion -eq $null)
		{
		$NewEnvVersion = $env:UATenvVersion
		}
	else
		{
		$NewEnvVersion = $env:SITTestEnvVersion
		}
	}
else 
	{
	$NewEnvVersion = $env:SITDevEnvVersion
	}

if ($env:SITDevAppName -eq $null)
	{
	if ($env:SITtestAppName -eq $null)
		{
		$envAppNameNew = $env:UATAppName
		}
	else
		{
		$envAppNameNew= $env:SITtestAppName
		}
	}
else 
	{
	$envAppNameNew = $env:SITDevAppName
	}

if ($env:SITDevMainUrl -eq $null)
	{
	if ($env:SITtestMainUrl -eq $null)
		{
		$envMianUrlNew = $env:UATMainUrl
		}
	else
		{
		$envMianUrlNew = $env:SITtestMainUrl
		}
	}
else 
	{
	$envMianUrlNew = $env:SITDevMainUrl
	}


$envVersionNew= "$NewEnvVersion"
$envAppNameNew = "$NewEnvAppName"
$envMianUrlNew = "$NewEnvmainUrl"


Write-Host -BackgroundColor DarkGray 'String {"' $$envVersionOld'"} replaced with with : {"' $envVersionNew '"}'
$InputFiles | ForEach { (Get-Content -Path $_.FullName).Replace($envVersionOld,$envVersionNew) | Set-Content -Path $_.FullName }
$InputFiles | ForEach { (Get-Content -Path $_.FullName).Replace($envAppNameOld,$envAppNameNew) | Set-Content -Path $_.FullName }
$InputFiles | ForEach { (Get-Content -Path $_.FullName).Replace($envMainurlOldOld,$envMianUrlNew) | Set-Content -Path $_.FullName }

write-host "writing to files completed. Go to $InputFiles and check."

}
else
{
Write-Host $OldString -BackgroundColor Magenta "is Not Present in " 
write-host $InputFiles
}
}
else{Write-Host "file not found"}