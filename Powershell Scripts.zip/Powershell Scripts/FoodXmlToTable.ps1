﻿#this function block will add/alter the contents of breakfast_menu contents. 
function Add-Food
{
[xml]$xmlEdit = Get-Content $path

param(
[Parameter(Mandatory=$true,Position=0)]
[string]$index_value,

[Parameter(Mandatory=$true,Position=1)]
[string]$name,

[Parameter(Mandatory=$true,Position=2)]
[string]$price,

[Parameter(Mandatory=$true,Position=3)]
[string]$description,

[Parameter(Mandatory=$true,Position=4)]
[string]$calories
)

if($xmlEdit.breakfast_menu.food.name[$index_value] -ne $name){
    $xmlEdit.breakfast_menu.food[$index_value].name = $name
    }
else{
    Write-Host "Food name already exists, Hence value won't be changed"
    }

if($xmlEdit.breakfast_menu.food.price[$index_value] -ne $price){
    $xmlEdit.breakfast_menu.food[$index_value].price = $price
    }
else{
    Write-Host "Food price already exists, Hence value won't be changed"
    }

if($xmlEdit.breakfast_menu.food.description[$index_value] -ne $description){
    $xmlEdit.breakfast_menu.food[$index_value].description = $description
    }
else{
    Write-Host "Food description already exists, Hence value won't be changed"
    }

if($xmlEdit.breakfast_menu.food.calories[$index_value] -ne $calories){
    $xmlEdit.breakfast_menu.food[$index_value].calories = $calories
    }
else{
    Write-Host "Food calories already exists, Hence value won't be changed"
    }

Write-Host("view altered file at : ")  +  $path 

$xmlEdit.Save($path)

}

#Dialog box pop up for choosing a file
Add-Type -AssemblyName System.Windows.Forms
$FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{
    Multiselect = $false # Multiple files can not be chosen on same pop up window
	Filter = 'XML Files Only(*.xml)|*.xml;' # Specified file types only can be selected
}
 
[void]$FileBrowser.ShowDialog()

$path = $FileBrowser.FileNames;
#$path conatins the path of xml file 

#type casting xml contents to a variable $XmlDocument from the defined path
[xml]$XmlDocument = Get-Content -Path $path


$XmlDocument.GetType().FullName   #Displays XmlDocument full name
$XmlDocument      #Dipalys the element of xml


#Displays contents inside breakfast_menu node(Marker elements of xml)
$XmlDocument.breakfast_menu   
 #unformated table view
$XmlDocument.breakfast_menu.food | Format-Table -Wrap  
#Displays contents inside food node(Marker elements of xml)
$XmlDocument.breakfast_menu.food | Format-Table -AutoSize -Wrap #centered and extra spaces removed

#only specific data can be retrived by passing index value of naode
$XmlDocument.breakfast_menu.food[2]|Format-Table -Wrap -AutoSize
$XmlDocument.breakfast_menu.food[0]|Format-Table -Wrap -AutoSize
$XmlDocument.breakfast_menu.food[0]|Format-Table -Wrap -AutoSize -HideTableHeaders #header are removed

Add-Book #this calls the function Add-Book.
