﻿function delBy_Author
{
 param(
[Parameter(Mandatory=$true,Position=0)]
[string]$author_name
)
[xml]$xdoc = Get-Content $path
$del_book = $xdoc.catalog.book | Where-Object {$_.author -eq $author_name}
$xdoc.catalog.RemoveChild($del_book)
Write-Host "the above book deleted succesfully."
$xdoc.Save($path)
}

function delBy_title
{
 param(
[Parameter(Mandatory=$true,Position=0)]
[string]$title
)
[xml]$xdoc = Get-Content $path
$del_book = $xdoc.catalog.book | Where-Object {$_.title -eq $title}
$xdoc.catalog.RemoveChild($del_book)
Write-Host "the above book delet+
ed succesfully."
$xdoc.Save($path)
}

Read-Host "Enter any key to select xml file"
####################################################################################################
#                    Dialog box pop up for choosing a file
####################################################################################################
    Add-Type -AssemblyName System.Windows.Forms
    $FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{
    Multiselect = $true           # Multiple files can be chosen on same pop up window
    Filter = 'All Files (*.*)|*.*;'       #select any file type.
    }
 
    [void]$FileBrowser.ShowDialog()

###################################################################################################
#    $path conatins the path of files selected
####################################################################################################    
    
    $path = $FileBrowser.FileNames;

    $svalue = Read-Host "select the menu :
        1. Delete using author name.
        2. Delete using title name. 
      "

    switch($svalue)
    {
      1
        {
        delBy_Author
        }
      2
        {   
        delBy_title
        }
    }
