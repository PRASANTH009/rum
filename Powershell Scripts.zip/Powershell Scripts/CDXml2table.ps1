﻿Add-Type -AssemblyName System.Windows.Forms
$FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{
    Multiselect = $true # Multiple files can be chosen
	Filter = 'XML (*.xml)|*.xml;' # Specified file types
}
 
[void]$FileBrowser.ShowDialog()

$path = $FileBrowser.FileNames;

[xml]$XmlDocument = Get-Content -Path $path
$XmlDocument.GetType().FullName
$XmlDocument
$XmlDocument.CATALOG
$XmlDocument.CATALOG.CD #unformated table view
$XmlDocument.CATALOG.CD | Format-Table -AutoSize
$XmlDocument.CATALOG.CD[0]|Format-Table -AutoSize