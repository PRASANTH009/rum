﻿$browser = New-Object -ComObject internetexplorer.application
$browser.Navigate2("https://www.github.com/rithwika")
$Browser.visible=$true


 Start-Process 'C:\Users\28587\AppData\Local\Programs\Git\git-bash.exe'
 $pingTest = 'git log'
 $pingTest
    Invoke-Expression $pingTest
    Invoke-Command $pingTest


    C:\Users\28587\AppData\Local\Programs\Git\git-bash.exe | echo "git log"

    Set-Location C:\path\to\myrepo.git\
    Git log

    $env:Path -split ‘;’ | Select-String -SimpleMatch git

    Start-Process "chrome.exe" "www.google.com"
    $ie = Start-Process "chrome.exe" "https://i3lmobile.itcinfotech.com/psp/OPPORTAL/?cmd=login"
    
    $usernmae="28587"

    $password="Vish@123"

    $usernamefield = $ie.document.getElementByID('userid')
    $usernamefield.value = $username

    $passwordfield = $ie.document.getElementByID('pwd')
    $passwordfield.value = $password

    $Link = $ie.document.getElementByID('ps-button')
    $Link.click()