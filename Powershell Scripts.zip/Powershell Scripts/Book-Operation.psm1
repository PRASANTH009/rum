﻿####################################################################################################
#        the delete book function deletes the book if matched value is $arg1 is matched.           #
####################################################################################################

function Remove-Book([string]$path, [string]$author)
{

[xml]$xdoc = Get-Content $path 

if("Author" -match $author){
    param(
    [Parameter(Mandatory=$true,Position=0)]
    [string]$author_name
    )
    $del_book = $xdoc.catalog.book | Where-Object {$_.author -eq $author_name}
    }

else {
    param(
    [Parameter(Mandatory=$true,Position=0)]
    [string]$title
    )
    $del_book = $xdoc.catalog.book | Where-Object {$_.title -eq $title}
}

$xdoc.catalog.RemoveChild($del_book)
Write-Host "the above book deleted succesfully."
$xdoc.Save($path)
}

####################################################################################################
#              the add book function will add the book to the xml file                             #
####################################################################################################

function Upadte-Book([string]$path)
{

[xml]$xdoc = Get-Content $path

$index_value = Read-Host "enter index value "

if($index_value -ge $xdoc.catalog.book.Count){

$author_name = Read-Host "enter author name "
$title       = Read-Host "enter title "
$price       = Read-Host "enter price "

if ($xdoc.catalog.book.author[$index_value] -ne $author_name) {
$xdoc.catalog.book[$index_value].author = $author_name
}
else {
Write-Host "Author name already exists, Hence value won't be changed"
}

if ($xdoc.catalog.book.title[$index_value] -ne $title) {
$xdoc.catalog.book[$index_value].title = $title
}
else {
Write-Host "title value already exists, Hence value won't be changed already exists"
}

if ($xdoc.catalog.book.price[$index_value] -ne $price) {
$xdoc.catalog.book[$index_value].price = $price
}
else {
Write-Host "price value already exists, Hence value won't be changed already exists"
}
}
else {
Write-Warning "Wrong Index Value or Index value is not present."
}
$xdoc.Save("D:\Books.xml")
}



####################################################################################################
#                             View Book Working!!!!                                                #
####################################################################################################

function View-Book([path]$path, [string]$searchBy , [string]$search) {

[xml]$xdoc = Get-Content $path 
        
   $node = $xdoc.catalog.book | % {$_.$searchBy}|?{$_ -match $search} |select -First 1
   $new = $xdoc.catalog.book | Where-Object {$_.author -eq $node} 
   $new | Out-GridView

}

Export-ModuleMember -Function Remove-Book,Upadte-Book, View-Book -Alias db,vb,vb

