﻿Add-Type -AssemblyName System.IO.Compression.FileSystem
$mysite = "rithwika-s"
$myproject = "JavaApp"
$mybuild = "testbuild" # not really needed anymore
$buildid = "229" # you can find this one in the browser link
$dest = "d:\temp\zip\"

$Timestamp = Get-Date -format ddMMMyyyy-HHmmss;
$destination = $dest + "build-" + $buildid +".zip"
echo $destination
$outpath = "d:\temp\unzip"

$source = "https://"+  $mysite + ".visualstudio.com/DefaultCollection/" +$myproject + "/_build#definitionId=" + $buildid + "&_a=completed"
echo $source

# download the file
Invoke-WebRequest $source -OutFile $destination

#unzip the file 
Remove-Item -Recurse -Force $outpath
#[System.IO.Compression.ZipFile]::ExtractToDirectory($destination, $outpath)

