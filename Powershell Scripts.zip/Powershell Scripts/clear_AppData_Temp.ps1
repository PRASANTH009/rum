﻿Set-Location "C:\Users\28587\AppData\Local\Temp\*"
Remove-Item *.tmp -force -recurse
if (Test-Path $testfile)
{
    Write-Host -ForegroundColor Red ("File '{0}' still exists after 'Remove-item': test FAILS" -f $testfile)
}
else
{
    Write-Host -ForegroundColor DarkGreen ("File '{0}' no longer exists after 'Remove-item': test SUCCEEDS" -f $testfile)
}